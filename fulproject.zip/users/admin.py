from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import CustomUser

class CustomUserAdmin(UserAdmin):
    # Добавляем наши поля в форму редактирования пользователя в админке
    fieldsets = UserAdmin.fieldsets + (
        (None, {'fields': ('name', 'surname', 'patronymic')}),
    )

admin.site.register(CustomUser, CustomUserAdmin)