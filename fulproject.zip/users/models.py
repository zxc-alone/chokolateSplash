from django.contrib.auth.models import AbstractUser
from django.db import models

class CustomUser(AbstractUser):
    # В Django поле логина - это username. Пароль и email уже есть.
    name = models.CharField(max_length=50, verbose_name="Имя")
    surname = models.CharField(max_length=50, verbose_name="Фамилия")
    patronymic = models.CharField(max_length=50, blank=True, null=True, verbose_name="Отчество")
    
    # Переопределяем email, чтобы он был обязательным
    email = models.EmailField(unique=True)

    def __str__(self):
        return self.username