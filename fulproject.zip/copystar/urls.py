
from django.contrib import admin
from django.urls import path
from shop import views as shop_views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    
    # Наши страницы
    path('', shop_views.index, name='index'),
    path('catalog/', shop_views.catalog, name='catalog'),
    path('product/<int:pk>/', shop_views.product_detail, name='product_detail'),
    
    # AJAX запросы (API)
    path('cart/add/', shop_views.cart_add, name='cart_add'),
]

# Чтобы картинки отображались при локальной разработке
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)