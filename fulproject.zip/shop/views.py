class Cart:
    def __init__(self, request):
        self.session = request.session
        cart = self.session.get('cart')
        if not cart:
            cart = self.session['cart'] = {}
        self.cart = cart

    def add(self, product, quantity=1):
        product_id = str(product.id)
        if product_id not in self.cart:
            self.cart[product_id] = {'quantity': 0, 'price': str(product.price)}
        
        # Проверка: не больше, чем есть на складе
        if self.cart[product_id]['quantity'] + quantity <= product.stock:
            self.cart[product_id]['quantity'] += quantity
            self.save()
            return True
        return False

    def save(self):
        self.session.modified = True

    def remove(self, product_id):
        product_id = str(product_id)
        if product_id in self.cart:
            del self.cart[product_id]
            self.save()
    
    def __len__(self):
        return sum(item['quantity'] for item in self.cart.values())





    from django.shortcuts import render, get_object_or_404, redirect
from django.http import JsonResponse
from .models import Product, Category
from .cart import Cart
import json

def index(request):
    # Для слайдера: 5 последних товаров
    latest_products = Product.objects.order_by('-created_at')[:5]
    return render(request, 'shop/index.html', {'latest_products': latest_products})

def catalog(request):
    products = Product.objects.all()
    categories = Category.objects.all()
    
    # Фильтрация по категории
    category_id = request.GET.get('category')
    if category_id:
        products = products.filter(category_id=category_id)
        
    # Сортировка
    sort = request.GET.get('sort')
    if sort == 'price_asc':
        products = products.order_by('price')
    elif sort == 'price_desc':
        products = products.order_by('-price')
    elif sort == 'name':
        products = products.order_by('name')
    else:
        products = products.order_by('-created_at') # по новизне по умолчанию
        
    return render(request, 'shop/catalog.html', {'products': products, 'categories': categories})

def product_detail(request, pk):
    product = get_object_or_404(Product, pk=pk)
    return render(request, 'shop/product_detail.html', {'product': product})

# AJAX запрос на добавление в корзину
def cart_add(request):
    if request.method == 'POST':
        if not request.user.is_authenticated:
            return JsonResponse({'status': 'error', 'message': 'Необходимо авторизоваться'}, status=403)
            
        data = json.loads(request.body)
        product_id = data.get('product_id')
        product = get_object_or_404(Product, id=product_id)
        
        cart = Cart(request)
        if cart.add(product=product):
            return JsonResponse({'status': 'success', 'cart_count': len(cart)})
        else:
            return JsonResponse({'status': 'error', 'message': 'Товар закончился на складе'})